<h1 align="center">Inumaki</h1>

# Overview

<p align="center">
  <img alt="Preview" width="860" alt="preview" src="https://i.imgur.com/BnLAQtq.png">
  <img alt="Preview" width="860" alt="preview" src="https://i.imgur.com/IhvnvS3.png">
<p align="center">

<p align="center">Jujutsu Kaisen Inumaki Toge Theme.</p>

---

# Installation

### BetterDiscord

1. Download the theme file [here](https://downgit.github.io/#/home?url=https://github.com/jpmn333/Inumaki/blob/main/Inumaki.theme.css).
2. Open your BetterDiscord themes folder.
3. Drag the file you downloaded into the folder. Ensure there isn't a copy identifier (eg `Name.theme(1).css`) at the end of the filename.

### Powercord

```cd powercord/src/powercord/themes && git clone https://github.com/jpmn333/Inumaki```
